# -*- coding: iso-8859-15 -*-
"""Simple FunkLoad test

$Id$
"""
import unittest
from random import random
from random import randint
from funkload.FunkLoadTestCase import FunkLoadTestCase

class Simple(FunkLoadTestCase):
    """This test use a configuration file Simple.conf."""

    def setUp(self):
        """Setting up test."""
        self.server_url = self.conf_get('main', 'url')

    def test_simple(self):
        # The description should be set in the configuration file
        server_url = self.server_url
        # begin of test ---------------------------------------------
#        nb_time = self.conf_getInt('test_simple', 'nb_time')
#        for i in range(nb_time):
#            self.get(server_url, description='Get url')
        # end of test -----------------------------------------------
	ID = randint(1, 100000)
	email = "username_" + str(ID) + "_SCALE_TEST"
	passwd = "username_" + str(ID)
	self.get(server_url + "/login/login", params = [
		['email', email],
		['password', passwd]],
		description="Login!")

	self.get(server_url + "/calendar/show", description="Calendar!")

	self.get(server_url + "/profile/show", description="Profile!")

#	print 'Profile:\n%s\n' % self.getBody()

	self.get(server_url + "/group/show", description="Group!")

	self.get(server_url + "/login/logout", description="Logout!")

if __name__ in ('main', '__main__'):
    unittest.main()
