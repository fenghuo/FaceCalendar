#!/bin/sh
# Runing the load test, generate statistical data and visualize them

if [ -f load_test ] ; then
	truncate load_test -s 0
fi

for i in $( seq $1 $2 $3 ) ; do
	echo -n $i >> load_test
	httperf --hog --session-cookie --server=75.101.185.175 --wsesslog=$i,1,$4 --rate=$5 | awk -f script.awk  >> load_test
done

#cat load_test

